/*
 * Aitezaz Siddiqi (A00431079)
 * JavaScript file for the project (Project P1)
 */