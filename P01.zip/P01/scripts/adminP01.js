/*
 * Aitezaz Siddiqi (A00431079)
 * JavaScript file for the project (Project P1)
 */

function confirmFrom() {

    var from = $("fromTextAdmin").val();

    if (from === null) {
        confirm("\"Press a button!\"");
    }

}
