/*
 * Aitezaz Siddiqi (A00431079)
 * JavaScript file for showing help windows (Project P1)
 */

const DIMENSIONS = "width=600, height=300, top=300, left=600";

function showHelpTo() {
    window.open("./helps/helpTo.html", "MsgWindow", DIMENSIONS);
}

function showHelpFrom() {
    window.open("./helps/helpFrom.html", "MsgWindow", DIMENSIONS);
}

function showHelpCc() {
    window.open("./helps/helpCc.html", "MsgWindow", DIMENSIONS);
}

function showHelpSubject() {
    window.open("./helps/helpSubject.html", "MsgWindow", DIMENSIONS);
}

function showHelpBody() {
    window.open("./helps/helpBody.html", "MsgWindow", DIMENSIONS);
}